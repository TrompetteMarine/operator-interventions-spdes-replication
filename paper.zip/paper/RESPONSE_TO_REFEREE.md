# Response to referee report — actions implemented (v4)

Repository: https://github.com/TrompetteMarine/operator-interventions-spdes-replication
Builds: `paper/pdf/paper_merged.pdf` (draft date line), `paper/pdf/paper_submission.pdf` (submission), 75 pp, no LaTeX errors, no undefined references.

## Item 2 — numerics not theorem-aligned  [ACCEPTED, implemented]
- All "theorem-aligned" language removed. The `n = 80 N^2` path is now described
  everywhere as a *fixed-resolution finite-sample illustration*
  (`lambda_N Delta_n = pi^2 T/80 ~ 0.123` constant), Section 9 and Fig. 3 caption.
- New regime scan (Section 9.2, Table 4; `make regime-scan`;
  `replication/scripts/regime_scan.py`, seeded, 300 reps/design, MC s.e. reported):
  aligned ladder `n = ceil(80 N^2 log N / log 5)` (`n/N^2 -> inf`), the fixed-resolution
  ladder, and a deliberately under-resolved ladder `n = 20 N` (`lambda_N Delta_n -> inf`).
  Result: aligned/fixed dispersions within MC error of 1 with cross-correlations inside
  the `sqrt(lambda_N Delta_n / T)` envelope; under-resolved dispersions diverge
  (sd(Z_theta): 1.53 -> 2.08 -> 3.32; corr -> 0.84). The scan separates the regime the
  theory covers from the regime where it fails. Estimation uses the corrected
  constrained profile MLE (clamp never active — consistent with the uniform-inactivity
  step of the consistency proof).
- Remaining (offer in response letter): coverage/bias/LR-remainder columns along the
  ladders at publication replication counts.

## Item 3 — "operator intervention" overstates the inference  [ACCEPTED in substance]
- Abstract and introduction now state the scope explicitly: known diagonal generator,
  two scalar parameters, primary intervention = scalar rescaling within {aA_0 : a>0};
  bounded perturbations enter only through the local sensitivity derivative
  (remedy 1 of the report). Title retained as an author-level decision; a narrower
  variant is proposed in the response letter.

## Item 4 — causal semantics conditional on the decomposition  [ACCEPTED]
- The conditionality is now stated up front (introduction scope paragraph), in the
  related-literature paragraph ("module surgery ... relative to a declared
  decomposition; not observationally determined"), and after Theorem 3.1.
  The phrase "rather than a relabelling of stochastic equations" is removed.

## Item 5 — novelty comparison  [ACCEPTED]
- New Table 1 (introduction): observation scheme, likelihood object, parameters, and
  result level for Huebner–Rozovskii (1995), Cialenco et al. (2020), Bibinger–Trabs
  (2020)/Chong (2020), Hildebrandt–Trabs (2021), Kaino–Uchida (2021), Tonaki et al.
  (2023, 2024) vs this paper. The claim is narrowed: experiment-level LAN under
  continuous observation is credited to HR95; the new element is the joint
  two-parameter exact-discrete-transition LAN at fixed horizon with
  diag(sqrt(Lambda_N), sqrt(Nn)), efficiency, and polynomial moments.

## Item 6 — finite-rank proportionality  [ACCEPTED]
- Abstract and Section 6 state that the multiplier is conditionally equivalent to an
  estimated 2-d Gaussian draw and that the contribution is uniform validity
  (derivative zeros, contact sets), not a high-dimensional bootstrap.

## Item 7 — eta_M scope  [ACCEPTED]
- Section 7 now states the topology precisely: eta_M bounds bounded perturbation
  directions in L(H); generator discretisations (FD/FEM) are excluded and require
  resolvent/form/semigroup convergence; Galerkin truncation and scalar rescaling are
  handled by the K^{-rho_F} term and analytic-semigroup calculus. The eta_M^2 claim in
  Theorem 7.2 now carries its hypotheses (uniform second-order differentiability,
  computable direction).

## Item 8 — hypotheses in the main theorem  [ACCEPTED]
- Assumption 5.1 restructured: (i) model/observation (Weyl growth, q_k > 0,
  Delta_n = T/n fixed horizon, interior true parameter); (ii) joint regime;
  (iii) initial energy. New Remark 5.3 ("Hypothesis accounting") maps each conclusion
  of Theorem 5.1 to the hypotheses it uses, including the spectral-growth condition
  for consistency and its inheritance.

## Item 9 — not submission-ready  [ACCEPTED, all verified and fixed]
- "Programme status" paragraph deleted (wp8 source).
- Proof-map numbering corrected (Prop. 3.1/Thm. 3.1; Lem. 4.1/Thm. 4.1/Prop. 4.1).
- Bibliography: duplicate Da Prato–Kwapien–Zabczyk entries merged (short keys
  normalised to canonical entries throughout sources and build script); the printed
  "update volume/pages at submission" note removed; proper Villani (2009) and
  Carcamo–Cuevas–Rodriguez (2020, Bernoulli 26(3)) entries added.
- "all authors" -> single-author wording.
- Data-and-code statement now names the public repository; the DOI note refers to the
  tagged release to be archived on acceptance.
- The formalisation claim is now verifiable: the Lean 4 archive and audit reports ship
  in `formalization/` of the repository, mapped to numbered statements
  (paper/CHANGES_AUDIT_v3.md).

## Item 10 — reproducibility  [ACCEPTED]
- Repository URL in Declarations and README; seeds, replication counts, MC standard
  errors, machine-readable configs documented; `make regime-scan` added; deterministic
  vs statistical verification distinguished in Section 9's opening.

## Item 11 — additional comments
- (1) Title: retained, scoping added; narrower variant offered.  (2) Abstract now
  distinguishes scalar rescaling / bounded sensitivity / marginal laws / unit-level
  contrasts.  (3) Done (item 2).  (4) "Sharp" qualified constructively in Section 8.
  (5) Proposition 4.1: nuisance spaces, domains, and codomains of M_theta, K_theta,
  L_{a,w}, V_{a,w} now displayed; closure caveat stated.  (6)-(7) Done (item 9).
  (8) Done.  (9) Done (Section 9 opening).  (10) Length: the imported-statement part
  (S0) and proofs section are retained by design; transfer to supplementary material
  is offered to the editor as an option.

## Where we push back (for the response letter)
- The report identifies no mathematical error and concedes no counterexample to the
  principal LAN statement; every blocking issue is presentational, numerical-design,
  or editorial. With the regime scan added and the scope narrowed in text, we believe
  the substance supports major-revision handling rather than reject-and-resubmit.
- Item 6 understates the content of the band theory: uniform validity at derivative
  zeros (floor studentisation) and one-sided contact-set inference are not delta-method
  trivialities, although the finite-rank geometry is exactly as the referee describes
  and is now stated as such.
