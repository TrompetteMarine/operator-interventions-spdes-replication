# Theorem registry — single source of truth for statement signatures

One row per main-text statement. "Model namespace" fixes the stochastic
mechanism; a theorem may not silently switch namespaces between main text,
proof, Lean, and numerics. Formalisation statuses are component-level and
defined in `../formalization/FORMALISATION_STATUS.md`.

Namespaces:
- `core`: diagonal additive SPDE, known (A0,Q), deterministic known u0,
  unknown scalars (theta,sigma), exact discrete spectral observation,
  Delta_n = T/n, fixed horizon.
- `core+galerkin`: `core` with spectral projection P_K.
- `noise_cov_partial_obs`: dU = theta A0 U dt + C^{1/2} dW, U0 = u known,
  Y = H U; nuisance = (u, C), C convex class of positive trace-class
  DRIVING-NOISE covariances (not initial covariances).
- `enlarged_*`: the non-identification enlargements of Section 8.

| ID | Statement | Namespace | Key hypotheses (verbatim source) | Proof | Lean components | Status | Numerics |
|---|---|---|---|---|---|---|---|
| P2.1 | Gaussian counterfactual law | core | Ass. 2.1 | Part S2 | modal variance algebra | PARTIALLY_FORMALISED | variance curve |
| P3.1 | Exact SCM representation | core+galerkin | none beyond model | Part S1 | gauge identities | PARTIALLY_FORMALISED | exact-identity tests |
| T3.1(i) | Maximal Galerkin rate | core+galerkin | alpha>0, delta>0 (wlog <1/2), u0 in D((-A0)^alpha), sum q_k^2 lambda_k^{2(alpha+delta)-1}<inf | Part S1 | — | PAPER_PROOF_ONLY + EXTERNAL (factorisation) | spatial slopes |
| T3.1(ii,iii) | Integrated/functional convergence | core+galerkin | u0 in H, sum q_k^2/lambda_k<inf | Part S1 | — | PAPER_PROOF_ONLY | spatial slopes |
| L4.1 | Fibre criterion | core | none | Part S2 | fibre criterion | KERNEL_CHECKED | — |
| T4.1 | Exact spectral identification | core | q_k>0, three observation times | Part S2 | recovery + injectivity | KERNEL_CHECKED (finite-dim core) | exact recovery test |
| P4.1 | Partial-observation kernel criterion | noise_cov_partial_obs | convex C, difference sets; closed observability span | Part S2 (thm:operator-kernel) | finite-dim analogues | PARTIALLY_FORMALISED | — |
| T5.1 | Mixed-rate LAN + MLE | core | Ass. 2.1 + Ass. 5.1(i)-(iii); consistency & moments additionally: N sqrt(lambda_N)=o(Lambda_N) (Remark 5.3) | Part S3 | see status table | PARTIALLY_FORMALISED | fixed-resolution + regime scan |
| T6.1, T6.2 | Uniform target processes; quantiles/tails | core | T5.1 conditions + compact T, inf V_a(w)>0 | Part S4 | — | PAPER_PROOF_ONLY | CDF/effect RMSE |
| T6.3 | Simultaneous bands (+floor) | core | T6.1 + floor rates; grid condition r omega(h_m)->0 (Part S5) | Part S5 | floor-studentised bounds | PARTIALLY_FORMALISED | coverage study |
| T7.1 | Operator-to-law differentiability | core + bounded B in L(H) | bounded direction | Part S6 | — | PAPER_PROOF_ONLY | FD-derivative check |
| T7.2 | Combined target error (renamed) | core+galerkin + bounded-direction eta_M | eta_M bounded-direction only; scheme-specific kappa | Part S7 | three-stage assembly | PARTIALLY_FORMALISED | slope checks |
| C7.1 | First-order response correction | as T7.2 | uniform 2nd-order differentiability; direction computed to o(eta_M) | Part S7 | — | PAPER_PROOF_ONLY | remainder quadraticity |
| T8.1 | Operator–forcing gauge | enlarged_feedback | unrestricted L | Part S8 | gauge identity | PARTIALLY_FORMALISED | exact equality checks |
| T8.2 | Boundary assembly | enlarged_* | per-clause enlargements | Part S8 | cross-world variance algebra | PARTIALLY_FORMALISED | impossibility table |

Gate: a statement stays in the manuscript only if its namespace is fixed,
its hypotheses appear verbatim in the statement (or by explicit named
reference), the proof carries the same signature, the status is accurate,
and any numerical column is understood as illustration. Every entry's final column set includes the mandatory known-unformalised-burden information via the status table's external-burden column (formalization/FORMALISATION_STATUS.md).
