# v3 — Implementation of the Lean formalization audit (output-final_aristotle)

Source of corrections: `output-final_aristotle/` (FORMALIZATION_AUDIT.md,
INCREMENTAL_FORMALIZATION_AUDIT.md, CONTINUED_FORMALIZATION_PROGRESS.md,
ARISTOTLE_SUMMARY.md and the Lean sources in `RequestProject/`). The audited
PDF is bit-identical to the previous `paper/pdf/paper_merged.pdf`, so the
theorem numbers below refer to both.

## Substantive corrections (statements changed)

1. **Proposition 9.13 (exact profile likelihood) — construction was false in
   general.** The original "unconstrained profile in sigma^2, minimise over
   theta, project the scale once when necessary" does not produce the
   compact-parameter MLE (Lean counterexample:
   `projecting_scale_after_unconstrained_profile_can_fail`). Replaced by the
   corrected constrained construction (`wp_src/wp3_..._theorems.tex`): for
   every drift candidate the scale is clamped to the admissible interval
   (`gaussian_profile_pointwise_clamp` / `exactOU_pointwise_constrained_scale`),
   the clamped profile is minimised over the drift interval, and the result
   is a joint constrained minimiser with a converse and an existence claim
   (`corrected_profile_is_joint_min`, `joint_min_is_corrected_profile`,
   `exactOU_joint_min_exists`). The clamp-inactivity characterisation
   (`exactOU_scale_constraint_inactive_iff`) is stated without any appeal to
   consistency. Remark on the order of operations added.

2. **Theorem 9.13 (consistency) — hidden hypothesis.** The proof used the
   spectral-growth condition N*sqrt(lambda_N) = o(Lambda_N) (display (95) in
   the audited PDF; now display (75)) without stating it. The condition is
   now a named display with a status remark (automatic under Weyl growth;
   not implied by Assumption 9.6(i) — rate-logic failure machine-checked by
   `two_rate_conditions_do_not_imply_condition95`), stated as an explicit
   hypothesis of Theorem 9.13 and inherited by Theorems 9.14
   (asymptotic linearity), LAN efficiency, and polynomial moment
   convergence, by the WP5 regime assumption, and by the WP4 statistical
   input. Main text: Remark 5.2 records the condition; the Section 9
   heat-equation verification list already checks it.

3. **Consistency proof restructured (closure_wp3_consistency.tex).** The
   proof now runs through the corrected constrained profile. New Step 3
   proves *uniform* inactivity of the scale clamp from the fluctuation
   bounds (sup_theta |s^2(theta) - sigma_0^2| -> 0 in probability) before
   any use — no circularity: the reduction to the unconstrained profile is
   derived, not assumed. The spectral-growth condition is referenced from
   the statement instead of being introduced inside the proof.

4. **Theorem 9.28 proof (closure_wp5_contact.tex).** The claim that the
   (pointwise) floor is "bounded and bounded away from zero" is unjustified
   when kappa_{N,n} -> 0. Part (ii) now retains the floor-rate
   normalisation: the negative signal term is bounded through the upper
   envelope s_kappa <= ||s_hat||_inf alone, and the fluctuation term through
   the floor-rate bounds of Theorem 9.26's Steps 1-2 (valid at derivative
   zeros).

## Strengthened proofs (no statement change)

5. **Lemma 9.7 (closure_wp3_KL.tex).** Informal Taylor/mean-value steps
   replaced by the machine-checked skeleton: exact variance-ratio
   factorisation, resolved-mesh two-sided bound |h(theta_0)/h(theta) - 1|
   <= 8*thetaUpper*lambda*Delta under 2*thetaUpper*lambda_N*Delta_n <= 1
   (`ScaleRatioBounds.lean`, `OUSmallMesh.lean`), explicit half-life burn-in
   index ceil(log 2 / (2 theta_0 lambda_k Delta_n)) with the half-sample
   inequality (`BurnInConstruction.lean`, `ModalBurnIn.lean`), prefix/tail
   spectral summation (`SpectralSummation.lean`), and an explicit statement
   of the termwise-nonnegativity hypothesis the summation step needs
   (`low_mode_nonnegativity_is_necessary` shows it cannot be dropped).
   Closing remark records the machine-checked layer.

6. **Closures for Lemma 9.5, Lemma 9.6, Theorem 9.16, Theorem 9.22,
   Lemma 9.11, Theorem 9.26, Theorem 9.43.** Headers updated to audited v3;
   the deterministic cores machine-checked in Lean are recorded
   (positive-part/contact-set reductions and one-Lipschitz supremum map,
   fourth-moment no-dominance, floor-studentised linear/remainder bounds,
   three-stage triangle assemblies). The one-Lipschitz property is now used
   explicitly in the WP4 contact closure.

## Editorial

7. The eleven draft-only "[Verification pending.]" flags are retired; the
   \closuredraft machinery was removed from the preamble. The proofs-section
   introduction and the data/code declaration document the Lean audit and
   its two corrections. Both `paper_merged.pdf` (draft date line) and
   `paper_submission.pdf` rebuilt: 72 pages, no LaTeX errors, no undefined
   references or citations.

## Figures (same release)

- Fig 1 (fig_modal_transfer.tikz): labels moved outside the plotting areas
  (legends above, notes below); pedagogical shading added (persistence gap;
  innovation loads).
- Fig 3 (fig_rate_regimes.tikz): honest axis labels ("log scale" with raw
  ticks), one message per region, limit laws and rate arithmetic moved to
  the side panel, short boundary tag.
- Fig 4 (fig_band_contact.tikz): complete redesign — content clipped to the
  axes, floor-active region as a shaded vertical band, contact set on the
  tau-axis with a brace label, outside legend; no strikethrough/overlap
  artefacts.
- Fig 6 (fig_identification_boundary.tikz): baseline reference row shaded
  and separated from the freed-module rows by a heavy rule.
