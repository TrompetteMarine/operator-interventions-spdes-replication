# Round 2 — response to the repair programme (v5)

Reviewed document: `operator_interventions_spde_repair_program.md` (against the
75-page v4). Builds: `paper/pdf/paper_merged.pdf`, `paper/pdf/paper_submission.pdf`
(75 pp, no LaTeX errors, no undefined references).

## Verification of the P0 claims

- **P0-A (covariance-mechanism mismatch): CONFIRMED and repaired.** The proof
  theorem (Part S2, kernel characterisation) is the *driving-noise* covariance
  model with the Volterra observed-covariance map; the v4 main-text Proposition
  4.1 displayed the *initial-covariance propagation* map. The main text now
  states the noise-covariance model verbatim (same maps, same convex class,
  same difference-set criterion as the proof), explicitly distinguishes it from
  the random-initial mechanism (which appears only in the Section 8
  non-identification construction), and carries the closed observability span.
  One theorem signature across layers, per repair rule 2.

- **P0-B (algebraic vs closed span): NOT CONFIRMED.** The proof source already
  defines the observability subspace as the *closed* span
  (`\overline{span}{S_theta(t)* H* y}`) and applies the double-orthogonal-
  complement argument to the closed subspace. No defect existed at proof level.
  Implemented anyway: the closure is now surfaced in the main-text proposition
  with the (V^perp)^perp = closure caveat and the Curtain–Zwart / Tucsnak–Weiss
  references, so the point is visible where a reader would look for it.

- **P0-C (alpha >= 0 vs alpha > 0): CONFIRMED and repaired.** Theorem 3.1 is
  split into (i) quantitative maximal path convergence under alpha > 0 (with
  the "wlog delta < 1/2" downward-monotonicity note; the proof's factorisation
  exponents gamma < min{delta, 1/2}, p > max{2, 1/gamma} were already explicit
  in Part S1), (ii) integrated convergence under minimal trace summability
  (the alpha = 0 content, without a rate), and (iii) field-functional and
  Wasserstein convergence under (ii).

- **P0-D (repository inaccessible): PARTIALLY CONFIRMED / USER ACTION.**
  Automated fetches of the GitHub URL returned no content, consistent with a
  private or not-yet-pushed repository. All round-1 and round-2 material is in
  the working tree; remaining owner actions: commit, push, make public, tag the
  release matching the manuscript version, mint the archival DOI (Zenodo) at
  submission if the journal's anonymity policy permits.

## Priority-one repairs implemented

1. Deconvolution independence stated at first main-text invocation
   (independent of the latent path and across observation times).
2. Theorem 7.2 renamed to "Combined target error under spectral truncation,
   verified temporal approximation, and bounded-direction operator error";
   the first-order eta_M^2 correction is now a separate Corollary 7.1 with its
   hypotheses; kappa declared scheme-specific (exact recursion: no temporal
   error; Kruse 2014 cited); the three perturbation regimes are listed as
   never conflated.
3. Numerics terminology: Section 9 retitled "Numerical illustrations and
   regime diagnostics"; "validation/verification" language removed;
   "statistically indistinguishable / flat coverage" replaced by the
   quantified statement (pairwise variant differences <= 0.027, draw/grid
   differences <= 0.010, all within 1.5 Monte Carlo s.e. of a difference,
   sqrt(2) x 0.013 ~ 0.018).
4. Grid-to-continuum bridge surfaced in the main text (Section 6) pointing to
   the Part S5 grid-approximation proposition r_{N,n} omega_{T0}(h_m) -> 0.
5. Model card (WP0): Table 2 in Section 2 fixes the epistemic status of every
   component (known / unknown / invariant / analyst-specified); observation
   conventions (j = 0..n transitions, conditioning on Y_{k,0}, n Delta_n = T)
   stated in Section 4.
6. Literature: added Cialenco–Huang (2020, Stoch. Dyn.), Cheng–Cialenco–Gong
   (2020, SPA), Curtain–Zwart (1995), Tucsnak–Weiss (2009); Kruse (2014) was
   already present and is now cited in Section 7; the polynomial
   likelihood-ratio bound is positioned relative to Yoshida (2011) in Remark
   5.2. Not added (metadata not independently verifiable at this pass):
   Alsenafi–Alazemi–Es-Sebaiy (2024), Ondrejat–Prohl–Walkington (2023),
   Auestad (2026) — to verify and add at proof stage.
7. Formalisation integrity (repair rules 4, 11–12): new
   `formalization/FORMALISATION_STATUS.md` with the five-status component
   vocabulary, per-component Lean names, external burdens, and the archive's
   negative tests; new `paper/theorem_registry.md` fixing model namespace,
   hypotheses, proof location, Lean components, and status per main-text
   statement; the proofs-section preamble now states that coverage is
   component-level, never theorem-level.

## Where we push back (for the letter)

- P0-B is stated as a confirmed defect but is not present in the source; the
  proof used the closed span throughout. We surface it in the main text as an
  improvement, not a correction.
- The heavier engineering items (full YAML registry with CI gates, paper
  theorems generated from Lean signatures, clean-container reproduction in CI)
  are adopted in lightweight form (markdown registry + status table + existing
  seeded manifests); full automation is planned for the archival release, not
  a precondition of scientific correctness.
- The programme's own framing agrees the central mixed-rate calculation is not
  contradicted; with P0-A and P0-C repaired, the remaining distance to
  submission is the repository release (P0-D), an owner action.
