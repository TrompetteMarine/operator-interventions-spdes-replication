# Submission manifest (v5, round-3 final pass)

Binding of the submitted artefacts to the repository state. Fill the git
fields at tag time; the PDF must be rebuildable from the tagged release via
`make paper`.

| Field | Value |
|---|---|
| paper_merged.pdf SHA-256 | a50760533b7ffb307fa2bc6621f708f26336cc61489c96b07384116939c2f6d3 |
| paper_submission.pdf SHA-256 | 66c78ca2a40417c27af3c7856fb38350934083af0b197c871230355dcaf8c5bf |
| Git commit SHA | [fill at commit] |
| Release tag | [fill at tag, e.g. v5-submission] |
| Lean toolchain | leanprover/lean4:v4.28.0 |
| Mathlib pin | see formalization/lake-manifest.json |
| Python | Python 3.10.12 |
| Simulation configs | replication/config/profiles.json (+ regime_scan.py constants) |
| Results manifest | replication/results/logs/results_manifest.json |

Gates: `make verify` (unit tests), `make lean-audit` (no sorry/admit/axiom),
`make verify-manifest` (results drift), `make regime-scan`,
`make reproduce-publication`, `make paper`.
