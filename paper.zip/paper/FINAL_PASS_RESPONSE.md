# Round 3 — response to the final pre-submission pass (v5)

Reviewed document: `final_pre_submission_pass_and_lean_gaps.md` (against the
75-page v4). Builds: 76 pp, no LaTeX errors, no undefined references;
manifest in `MANIFEST_SUBMISSION.md`.

## Priority A — verification and repairs

**A1 (floor-studentiser rate): CONFIRMED — the sharpest catch of all three
rounds — and repaired.** The v3/v4 closure's Step 3 asserted uniform ratio
consistency of the floored studentiser from plain uniform consistency; that
is insufficient, because the comparison denominator is of order
kappa_{N,n}. Repair implemented end-to-end:
- Theorem 6.3 now defines the studentiser by the *plug-in closed-form
  information* s_hat(tau)^2 = d_tau(theta_hat)^T J(theta_hat)^{-1}
  d_tau(theta_hat), so s_hat inherits the parameter rates (fast surfaces
  and J_sigma_sigma depend on sigma_hat alone -> O_P((Nn)^{-1/2}); slow ->
  O_P(Lambda_N^{-1/2}));
- the stated floor conditions then *imply* the relative rate
  ||s_hat - s||_inf = o_P(kappa_{N,n}) — they do double duty, and the
  theorem says so;
- the closure's Step 3 is rewritten as (rate) + (ratio lemma):
  |max(a,c)-max(b,c')| <= |a-b| + |c-c'| gives
  sup |s_hat_kappa/s_kappa - 1| <= 2||s_hat - s||_inf/(kappa ||s||_inf) ->_P 0;
- the multiplier covariance continues to use the outer-product J_hat of
  Lemma (Jhat), for which plain consistency suffices; only the studentiser
  needs a rate — stated explicitly;
- the quantile-continuity assumption, already present in the Part S5
  statement, is now visible in main-text Theorem 6.3 (with the conservative
  fallback when it fails).

**A2 (derivative-level numerical error): CONFIRMED and repaired.** The
value-level bound eta_M does not control parameter derivatives (the
eta_M sin(a/eta_M^2)B example). Section 7 now declares that wherever
derivative surfaces are approximated, eta_M bounds sup_a ||d^j/da^j E_{a,M}||
for j = 0,1,2 (trivial for parameter-independent errors), the temporal
scheme for derivatives carries its own consistency (automatic for the exact
recursion), and the Part S7 closure invokes the derivative-level hypothesis
at the exact display where it is used.

**A3 (prelimit vs limit): CONFIRMED and repaired.** The Section 7 expansion
now uses the prelimit linear process G_{f,N,n} := d_f^T A_{N,n}(theta_hat -
theta_0), states the expansion in C(T), and separately records
G_{f,N,n} => G_f, with the combined weak limit G_f + b_f under converging
bias.

**A4 (Theorem 7.1 hypotheses): CONFIRMED and repaired.** The theorem now
fixes A, states the semigroup bound and Hilbert–Schmidt noise admissibility
as hypotheses, declares the map B |-> U^{A+B} over L(H) (not
differentiability over a space of unbounded generators), and splits the
conclusion into (i) field differentiability, (ii) Gaussian-law
differentiability — the variance floor is used only in this clause —
and (iii) W2 stability under the shared-noise coupling.

**A5 (repository): USER ACTION.** Manifest with PDF SHA-256, toolchain, and
gate commands added; git SHA and tag to be filled at release.

## Priority B

- Prop 4.1: fixed-theta scope sentence added (maps linear only at fixed
  theta; theta identified by Thm 4.1); initial-state wording corrected to a
  deterministic nuisance class (the "fixed known initial state" phrase
  contradicted u in U and is removed).
- Prop 2.1: global summability displayed (Young for the causal kernel;
  V_a(w) <= sup_k(q_k^2/lambda_k) / (a_min^2 lambda_1) ||w||^2, uniform on
  the compact intervention set).
- Fig. 3: regions renamed "resolved/under-resolved region"; the caption
  states that regions classify designs while the theorem classifies
  sequences; side panel header "along LAN-aligned sequences"; ladder
  renamed LAN-aligned in Section 9 and Table 4.
- Clause mapping: theorem registry rows are clause-level (T3.1(i) vs
  (ii,iii)); status vocabulary harmonised to the five labels
  (IMPORTED_EXTERNAL_THEOREM, NUMERICAL_ILLUSTRATION).

## Priority C

- "Complete mathematical footing" -> explicit footing with a declared
  verification boundary; abstract's "Complete proofs" -> "Proofs of all
  statements"; Section 9 opens with "illustrates, does not certify".
- Formalisation narrative in the proofs preamble cut to a pointer paragraph;
  audit history lives with the archive.
- References verified and added: Ondrejat–Prohl–Walkington (2023, SPDE:A&C
  11(4), 1553–1634), Alsenafi–Alazemi–Es-Sebaiy (2024, ACDM 2024:52) —
  both DOIs confirmed; Auestad cited as arXiv:2406.02796 because the
  journal metadata proposed by the reviewer could not be independently
  confirmed.
- KS calibration note added (standardisation uses true simulation
  parameters, so the reference law is exact — the estimated-parameter
  recalibration concern does not apply here); coverage caption gains the
  95% MC half-width and the no-common-random-numbers statement.
- `make lean-audit` (fails on sorry/admit/sorryAx/project axioms; passes on
  the 19 archive files) and `make verify-manifest`
  (SHA-256 drift check on committed result tables; recorded and passing)
  added; `MANIFEST_SUBMISSION.md` binds the PDFs to the repository state.

## Not implemented (declared, with reasons)

- New Lean wrapper files and the two new negative regression tests (floor
  ratio; derivative approximation): the sandbox has no Lean toolchain to
  kernel-check new code, and unverified .lean files would violate the very
  standard the pass enforces. They are recorded as planned obligations in
  FORMALISATION_STATUS.md's negative-test section and the response letter.
- Full CI (clean-container reproduction, signature diffing): adopted in
  lightweight form via the make gates; full automation at the archival
  release.

## Assessment of the reviewing document

The document identifies one genuine proof gap (A1) that survived two
previous rounds, two genuine statement-hypothesis gaps (A2, A4), and one
notation-level rigor issue (A3); all four verified against the sources
before repair. Its Lean-boundary framing (formalised deterministic cores +
identified external inputs + paper proofs of asymptotic steps) matches the
paper's declared position exactly. Its reference metadata is imperfect
(Auestad journal attribution unconfirmable), which is consistent with the
simulated provenance; everything else checked out.
